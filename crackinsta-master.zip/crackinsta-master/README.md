# crackinsta
This tool is combained from 
+ CUPP - Common User Passwords Profiler Tool
+ Crackinsta Tool

# Installation steps in Termux & Kali linux
Check Link : http://jtechcode.blogspot.com/2020/01/instagram-password-hacking-using-termux.html

# Requirements 
python3

pip latest version
# Disclaimer
The above all files for informational and educational purposes only. About information security, penetration testing and security in general and increasing security awareness. This account does not promote or encourage any illegal Activities, all contents are provided by this channel is meant for Educational purpose only.
